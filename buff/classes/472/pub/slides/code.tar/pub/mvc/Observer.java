// Observer(293).Observer

interface Observer {
  void update();
}
