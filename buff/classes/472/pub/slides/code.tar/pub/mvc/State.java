public class State {

  public StringBuffer str=new StringBuffer();
  public int pos=0;

}
