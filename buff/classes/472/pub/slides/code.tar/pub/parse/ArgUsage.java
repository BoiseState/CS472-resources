public class ArgUsage extends Arg {

    public void init(Args args) {
	Error.fatal(args.toString());
    }

}
