// Adapter(139): Target

interface FileRead {

  void init();
  String read();

}
