// Prototype(117): Prototype

interface SetMapData<Key,Data> {
    Data add(Key data);
    int size();
    Data newData();
}
