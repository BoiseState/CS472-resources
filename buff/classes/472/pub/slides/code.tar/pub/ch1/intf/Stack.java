interface Stack<Data> {
    Data get();
    void put(Data data);
}
