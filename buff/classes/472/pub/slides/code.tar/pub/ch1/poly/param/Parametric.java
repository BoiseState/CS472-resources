// javac Parametric.java && java Parametric

public class Parametric {

    public static void main(String[] args) {
	Pair<String,Integer> p=new Pair<String,Integer>("Hi",100);
	System.out.println(p);
    }

}
