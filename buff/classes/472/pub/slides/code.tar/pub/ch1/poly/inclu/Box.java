interface Box<Item> {
    void put(Item item);
    Item get();
}
