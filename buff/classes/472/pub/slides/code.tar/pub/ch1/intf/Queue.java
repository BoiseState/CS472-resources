interface Queue<Data> {
    Data get();
    void put(Data data);
}
